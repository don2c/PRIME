Run:
  python prime_ring_eval_governed_opening.py --out_dir prime_ring_governed_opening_results --seed 0

Outputs:
  results.csv
  audit_log.csv
  table_governed_opening.tex
  transcripts_open_capsules_sample.csv
